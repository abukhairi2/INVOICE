import React from 'react';

function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Chendering Inn Invoice</h1>
      <p>This is your invoice app. You can now deploy and install it!</p>
    </div>
  );
}

export default App;